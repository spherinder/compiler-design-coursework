open Assert
open X86
open Simulator

(* You can use this file for additional test cases to help your *)
(* implementation.                                              *)


let provided_tests : suite = [
  Test ("Debug", [
  ]);

] 
